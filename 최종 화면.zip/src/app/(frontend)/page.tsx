import CatchApp from '@/components/CatchApp'

export default function HomePage() {
  return <CatchApp />
}
