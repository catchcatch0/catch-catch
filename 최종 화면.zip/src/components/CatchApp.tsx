"use client";

import { FormEvent, useMemo, useState } from "react";

type Product = {
  id: number;
  brand: string;
  name: string;
  price: number;
  original: number;
  image: string;
  tag: string;
  category: string;
  time: string;
  stock: number;
  saleEndsIn: number;
  marketplace: "coupang" | "temu" | "aliexpress";
};

const products: Product[] = [
  {
    id: 1,
    brand: "SONY",
    name: "WH-1000XM5 노이즈 캔슬링 헤드폰",
    price: 349000,
    original: 519000,
    image:
      "https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb?auto=format&fit=crop&w=900&q=85",
    tag: "역대가",
    category: "디지털",
    time: "4분 전",
    stock: 12,
    saleEndsIn: 75,
    marketplace: "coupang",
  },
  {
    id: 2,
    brand: "NIKE",
    name: "에어 포스 1 '07 화이트",
    price: 89900,
    original: 139000,
    image:
      "https://images.unsplash.com/photo-1608231387042-66d1773070a5?auto=format&fit=crop&w=900&q=85",
    tag: "36% 할인",
    category: "패션",
    time: "12분 전",
    stock: 7,
    saleEndsIn: 42,
    marketplace: "temu",
  },
  {
    id: 3,
    brand: "BIALETTI",
    name: "모카 익스프레스 3컵 커피메이커",
    price: 37900,
    original: 62000,
    image:
      "https://images.unsplash.com/photo-1638129284529-bed6d6f588e7?auto=format&fit=crop&w=900&q=85",
    tag: "무료배송",
    category: "리빙",
    time: "18분 전",
    stock: 24,
    saleEndsIn: 310,
    marketplace: "aliexpress",
  },
  {
    id: 4,
    brand: "BEATS",
    name: "Solo3 무선 온이어 헤드폰",
    price: 159000,
    original: 269000,
    image:
      "https://images.unsplash.com/photo-1545127398-14699f92334b?auto=format&fit=crop&w=900&q=85",
    tag: "오늘만",
    category: "디지털",
    time: "31분 전",
    stock: 5,
    saleEndsIn: 18,
    marketplace: "coupang",
  },
  {
    id: 5,
    brand: "NIKE",
    name: "에어맥스 데일리 스니커즈",
    price: 109000,
    original: 169000,
    image:
      "https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?auto=format&fit=crop&w=900&q=85",
    tag: "쿠폰특가",
    category: "패션",
    time: "42분 전",
    stock: 18,
    saleEndsIn: 140,
    marketplace: "temu",
  },
  {
    id: 6,
    brand: "EARLYBIRD",
    name: "홈카페 드립 커피메이커",
    price: 68900,
    original: 99000,
    image:
      "https://images.unsplash.com/photo-1603889780734-c4fb812e65e6?auto=format&fit=crop&w=900&q=85",
    tag: "31% 할인",
    category: "리빙",
    time: "1시간 전",
    stock: 32,
    saleEndsIn: 540,
    marketplace: "aliexpress",
  },
  {
    id: 7,
    brand: "SAMSUNG",
    name: "갤럭시 워치6 블루투스 44mm",
    price: 219000,
    original: 359000,
    image:
      "https://images.unsplash.com/photo-1579586337278-3befd40fd17a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    tag: "39% 할인",
    category: "디지털",
    time: "8분 전",
    stock: 9,
    saleEndsIn: 33,
    marketplace: "coupang",
  },
  {
    id: 8,
    brand: "ROUND LAB",
    name: "자작나무 수분 크림 80ml 기획 세트",
    price: 18900,
    original: 32000,
    image:
      "https://images.unsplash.com/photo-1585945037805-5fd82c2e60b1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    tag: "오늘 마감",
    category: "뷰티",
    time: "15분 전",
    stock: 21,
    saleEndsIn: 96,
    marketplace: "temu",
  },
  {
    id: 9,
    brand: "JBL",
    name: "FLIP 6 방수 블루투스 스피커",
    price: 99900,
    original: 169000,
    image:
      "https://images.unsplash.com/photo-1582978571763-2d039e56f0c3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    tag: "한정 수량",
    category: "디지털",
    time: "27분 전",
    stock: 6,
    saleEndsIn: 24,
    marketplace: "aliexpress",
  },
];

const categories = ["전체", "디지털", "패션", "뷰티", "리빙", "식품", "여행"];
const formatPrice = (price: number) => price.toLocaleString("ko-KR") + "원";
const discountRate = (product: Product) => Math.round((1 - product.price / product.original) * 100);
const formatSaleDeadline = (minutes: number) => minutes < 60 ? `${minutes}분 남음` : `${Math.floor(minutes / 60)}시간 ${minutes % 60}분 남음`;
const marketplaceLabels: Record<Product["marketplace"], string> = {
  coupang: "쿠팡 상품",
  temu: "Temu 상품",
  aliexpress: "AliExpress 상품",
};
function Icon({ name, size = 20 }: { name: string; size?: number }) {
  const paths: Record<string, React.ReactNode> = {
    search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-4-4" /></>,
    user: <><circle cx="12" cy="8" r="4" /><path d="M4 21c.5-5 3-7 8-7s7.5 2 8 7" /></>,
    heart: <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1.1L12 21l7.8-7.5 1.1-1.1a5.5 5.5 0 0 0-.1-7.8Z" />,
    bag: <><path d="M6 8h12l1 13H5L6 8Z" /><path d="M9 9V6a3 3 0 0 1 6 0v3" /></>,
    bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9" /><path d="M10 21h4" /></>,
    chevron: <path d="m9 18 6-6-6-6" />,
    arrow: <path d="M5 12h14m-5-5 5 5-5 5" />,
    close: <path d="m6 6 12 12M18 6 6 18" />,
    check: <path d="m5 12 4 4L19 6" />,
    cart: <><circle cx="9" cy="20" r="1" /><circle cx="18" cy="20" r="1" /><path d="M3 4h2l2 11h11l2-7H6" /></>,
    home: <><path d="m3 11 9-8 9 8" /><path d="M5 10v11h14V10M9 21v-7h6v7" /></>,
    comment: <path d="M21 15a4 4 0 0 1-4 4H8l-5 3 1.7-5A8 8 0 1 1 21 15Z" />,
    plus: <path d="M12 5v14M5 12h14" />,
    link: <><path d="M10 13a5 5 0 0 0 7.1.1l2-2a5 5 0 0 0-7.1-7.1l-1.1 1.1" /><path d="M14 11a5 5 0 0 0-7.1-.1l-2 2A5 5 0 0 0 12 20l1.1-1.1" /></>,
  };
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      {paths[name]}
    </svg>
  );
}

function Header({
  onLogin,
  onLogout,
  onSearch,
  onNavigate,
  cartCount,
  isLoggedIn,
}: {
  onLogin: () => void;
  onLogout: () => void;
  onSearch: (term: string) => void;
  onNavigate: (view: string) => void;
  cartCount: number;
  isLoggedIn: boolean;
}) {
  const [term, setTerm] = useState("");
  const submit = (e: FormEvent) => {
    e.preventDefault();
    onSearch(term);
  };
  return (
    <header className="header">
      <div className="utility">
        <div className="container utility-inner">
          <span>오늘 발견한 핫딜 <b>1,284개</b></span>
          {isLoggedIn ? (
            <div className="member-utility"><span><b>캐치 회원님</b>, 반가워요</span><i /><button onClick={() => onNavigate("mypage")}>마이페이지</button><i /><button onClick={onLogout}>로그아웃</button></div>
          ) : (
            <div><button onClick={onLogin}>로그인</button><i /><button onClick={onLogin}>회원가입</button><i /><button>고객센터</button></div>
          )}
        </div>
      </div>
      <div className="container header-main">
        <button className="logo" onClick={() => onNavigate("home")} aria-label="캐치캐치 홈">
          CATCH<span>CATCH</span><em>●</em>
        </button>
        <form className="search" onSubmit={submit}>
          <input value={term} onChange={(e) => setTerm(e.target.value)} placeholder="CATCH 하고 싶은 상품의 URL을 여기에 붙여넣어주세요." aria-label="상품 URL 입력" />
          <button aria-label="검색"><Icon name="search" size={22} /></button>
        </form>
        <div className="quick-menu">
          <button className={isLoggedIn ? "member-button" : ""} onClick={() => isLoggedIn ? onNavigate("mypage") : onLogin()}><Icon name="user" /><span>{isLoggedIn ? "내 정보" : "마이"}</span>{isLoggedIn && <em />}</button>
          <button onClick={() => onNavigate("wishlist")}><Icon name="heart" /><span>찜</span></button>
          <button className="cart-button" onClick={() => onNavigate("cart")}><Icon name="cart" /><span>CATCH</span>{cartCount > 0 && <b>{cartCount}</b>}</button>
        </div>
      </div>
      <nav className="gnb">
        <div className="container nav-inner">
          <button className="category-all"><span className="hamburger" />전체 카테고리</button>
          <button className="active" onClick={() => onNavigate("home")}>홈</button>
          <button onClick={() => onNavigate("products")}>실시간 핫딜</button>
          <button onClick={() => onNavigate("catch-deals")}>CATCH 특가</button>
          <button onClick={() => onNavigate("market")}>장터</button>
        </div>
      </nav>
    </header>
  );
}

function ProductCard({ product, onClick, onCatch, showDeadline = false }: { product: Product; onClick: () => void; onCatch: () => void; showDeadline?: boolean }) {
  const discount = discountRate(product);
  const [liked, setLiked] = useState(false);
  return (
    <article className="product-card">
      <div className="product-image" onClick={onClick}>
        <img src={product.image} alt={product.name} />
        <span className="deal-tag">{product.tag}</span>
        <span className={`market-ribbon ${product.marketplace}`}>{marketplaceLabels[product.marketplace]}</span>
        <button className={`heart ${liked ? "liked" : ""}`} onClick={(e) => { e.stopPropagation(); setLiked(!liked); }} aria-label="찜하기">
          <Icon name="heart" size={19} />
        </button>
      </div>
      <button className="product-info" onClick={onClick}>
        <span className="brand">{product.brand}</span>
        <strong>{product.name}</strong>
        <div className="price"><b>{discount}%</b><em>{formatPrice(product.price)}</em></div>
        <del>{formatPrice(product.original)}</del>
      </button>
      <div className="product-foot">
        <span className={showDeadline ? "sale-deadline" : ""}><i className="live-dot" />{showDeadline ? formatSaleDeadline(product.saleEndsIn) : product.time}</span>
        <button onClick={onCatch}><Icon name="bell" size={15} /> CATCH</button>
      </div>
    </article>
  );
}

const trackedProducts = [
  { product: products[0], target: 330000, status: "목표가까지 19,000원 남음" },
  { product: products[7], target: 18000, status: "목표가 달성 임박!" },
];

function Home({ onNavigate, onSelect, onCatch }: { onNavigate: (v: string) => void; onSelect: (p: Product) => void; onCatch: (p: Product) => void }) {
  const [category, setCategory] = useState("전체");
  const [catchUrl, setCatchUrl] = useState("");
  const [registered, setRegistered] = useState(false);
  const visible = [...products]
    .filter((p) => category === "전체" || p.category === category)
    .sort((a, b) => discountRate(b) - discountRate(a))
    .slice(0, 4);
  return (
    <main>
      <section className="catch-home container">
        <div className="catch-url-panel">
          <span className="eyebrow">CATCH YOUR PRICE</span>
          <h1>사고 싶은 상품 링크만 넣으세요.<br /><b>최저가가 되면 알려드려요.</b></h1>
          <p>쿠팡, 네이버쇼핑, Temu, AliExpress 등 어디서 발견했든 괜찮아요.</p>
          <form onSubmit={(event) => { event.preventDefault(); if (catchUrl.trim()) setRegistered(true); }}>
            <span><Icon name="link" size={19} /></span>
            <input value={catchUrl} onChange={(event) => { setCatchUrl(event.target.value); setRegistered(false); }} placeholder="CATCH 하고 싶은 상품의 URL을 여기에 붙여넣어주세요." aria-label="CATCH 상품 URL" />
            <button type="submit">{registered ? "등록 완료" : "CATCH 등록"}</button>
          </form>
          {registered && <small className="url-success"><Icon name="check" size={14} /> 상품 URL이 등록됐어요. 가격 변화를 추적할게요.</small>}
        </div>
        <div className="tracked-head"><div><span className="live-label"><i className="live-dot" /> TRACKING</span><h2>내가 추적 중인 상품</h2><p>찜 목록의 상품 가격을 실시간으로 지켜보고 있어요.</p></div><button onClick={() => onNavigate("wishlist")}>찜 목록 전체보기 <Icon name="chevron" size={16} /></button></div>
        <div className="tracked-grid">
          {trackedProducts.map(({ product, target, status }) => <article className="tracked-card" key={product.id} onClick={() => onSelect(product)}>
            <div className="tracked-image"><img src={product.image} alt={product.name} /><span className={`market-badge ${product.marketplace}`}>{marketplaceLabels[product.marketplace]}</span></div>
            <div className="tracked-info"><span>{product.brand}</span><h3>{product.name}</h3><dl><div><dt>현재가</dt><dd>{formatPrice(product.price)}</dd></div><div><dt>목표가</dt><dd>{formatPrice(target)}</dd></div></dl><p><i className="live-dot" /> {status}</p></div>
            <button onClick={(event) => { event.stopPropagation(); onCatch(product); }} aria-label={`${product.name} 목표가 수정`}><Icon name="bell" size={18} /></button>
          </article>)}
        </div>
        <div className="popular-tracking">
          <div className="tracked-head"><div><span className="live-label">POPULAR CATCH</span><h2>다른 유저들이 많이 등록한 상품</h2></div><button onClick={() => onNavigate("products")}>TOP 상품 전체보기 <Icon name="chevron" size={16} /></button></div>
          <div className="popular-grid">{products.slice(3, 7).map((product, index) => <button key={product.id} onClick={() => onSelect(product)}><em>0{index + 1}</em><img src={product.image} alt="" /><span><small>{product.brand}</small><b>{product.name}</b><strong>{formatPrice(product.price)}</strong></span></button>)}</div>
        </div>
      </section>

      <section className="live-section">
        <div className="container">
          <div className="section-title">
            <div><span className="live-label"><i className="live-dot" /> LIVE</span><h2>지금 뜨는 실시간 핫딜</h2><p>가격과 재고 변화를 실시간으로 추적하고 있어요</p></div>
            <button onClick={() => onNavigate("products")}>전체보기 <Icon name="chevron" size={17} /></button>
          </div>
          <div className="category-tabs">
            {categories.slice(0, 6).map((item) => <button key={item} className={category === item ? "active" : ""} onClick={() => setCategory(item)}>{item}</button>)}
          </div>
          <div className="product-grid">
            {visible.map((p) => <ProductCard key={p.id} product={p} onClick={() => onSelect(p)} onCatch={() => onCatch(p)} />)}
          </div>
        </div>
      </section>

      <section className="catch-intro container">
        <div className="catch-copy">
          <span>CATCH LIVE DEAL</span>
          <h2>기다리던 가격,<br />놓치지 않게 잡아드려요</h2>
          <p>원하는 가격과 옵션만 정해두세요.<br />조건이 맞는 순간 바로 알려드릴게요.</p>
          <button onClick={() => onCatch(products[0])}>CATCH 알림 설정하기 <Icon name="arrow" /></button>
        </div>
        <div className="catch-steps">
          <div><b>01</b><span className="step-icon"><Icon name="search" /></span><strong>상품을 찾고</strong><p>여러 쇼핑몰을 한 번에 검색해요</p></div>
          <div><b>02</b><span className="step-icon"><span>₩</span></span><strong>목표가를 정하면</strong><p>가격과 재고를 계속 지켜봐요</p></div>
          <div><b>03</b><span className="step-icon"><Icon name="bell" /></span><strong>바로 알려드려요</strong><p>조건 충족 즉시 알림을 보내요</p></div>
        </div>
      </section>

      <section className="newsletter">
        <div className="container newsletter-inner">
          <div><span>WEEKLY CATCH</span><h2>이번 주 놓치면 아쉬운 딜만 모았어요</h2><p>매주 목요일, 엄선한 핫딜을 메일로 보내드려요.</p></div>
          <form onSubmit={(e) => e.preventDefault()}><input type="email" placeholder="이메일 주소를 입력하세요" /><button>구독하기</button></form>
        </div>
      </section>
    </main>
  );
}

function WishlistView({ onSelect, onCatch }: { onSelect: (p: Product) => void; onCatch: (p: Product) => void }) {
  return <main className="container listing"><div className="breadcrumb">홈 <Icon name="chevron" size={13} /> 찜</div><div className="listing-head"><div><span className="eyebrow">MY WISHLIST</span><h1>찜한 상품</h1><p>내가 추적 중인 상품과 같은 목록이에요.</p></div><b>{trackedProducts.length}개의 상품</b></div><div className="product-grid wide wishlist-grid">{trackedProducts.map(({ product }) => <ProductCard key={product.id} product={product} onClick={() => onSelect(product)} onCatch={() => onCatch(product)} />)}</div></main>;
}

function ProductsView({ query, onSelect, onCatch, catchDeals = false }: { query: string; onSelect: (p: Product) => void; onCatch: (p: Product) => void; catchDeals?: boolean }) {
  const [active, setActive] = useState("전체");
  const result = useMemo(() => products
    .filter((p) => (active === "전체" || p.category === active) && (!query || `${p.brand} ${p.name}`.toLowerCase().includes(query.toLowerCase())))
    .sort((a, b) => catchDeals ? a.saleEndsIn - b.saleEndsIn : discountRate(b) - discountRate(a)), [active, query, catchDeals]);
  return (
    <main className="container listing">
      <div className="breadcrumb">홈 <Icon name="chevron" size={13} /> {query ? "검색 결과" : catchDeals ? "CATCH 특가" : "실시간 핫딜"}</div>
      <div className="listing-head">
        <div><span className="eyebrow">{query ? "SEARCH RESULTS" : catchDeals ? "ENDING SOON" : "ALL LIVE DEALS"}</span><h1>{query ? `'${query}' 검색 결과` : catchDeals ? "CATCH 특가" : "실시간 핫딜"}</h1><p>{catchDeals ? "할인 종료가 얼마 남지 않은 상품부터 보여드려요." : "할인율이 높은 상품부터 빠르게 모았어요."}</p></div>
        <b>{result.length}개의 상품</b>
      </div>
      <div className="filter-row">
        <div>{categories.slice(0, 4).map((c) => <button className={active === c ? "active" : ""} onClick={() => setActive(c)} key={c}>{c}</button>)}</div>
        <button className="filter-button">{catchDeals ? "마감 임박순" : "할인율 높은순"} <span>⌄</span></button>
      </div>
      {result.length ? <div className="product-grid wide">{result.map((p) => <ProductCard key={p.id} product={p} onClick={() => onSelect(p)} onCatch={() => onCatch(p)} showDeadline={catchDeals} />)}</div> : (
        <div className="empty"><Icon name="search" size={36} /><h2>검색 결과가 없어요</h2><p>다른 검색어를 입력하거나 인기 키워드를 확인해보세요.</p><div><button>에어팟</button><button>나이키</button><button>자취템</button></div></div>
      )}
    </main>
  );
}

function DetailView({ product, onCatch, onAdd, onMove }: { product: Product; onCatch: () => void; onAdd: () => void; onMove: () => void }) {
  return (
    <main className="container detail">
      <div className="breadcrumb">홈 <Icon name="chevron" size={13} /> {product.category} <Icon name="chevron" size={13} /> {product.brand}</div>
      <div className="detail-grid">
        <div className="detail-image"><img src={product.image} alt={product.name} /><span className="deal-tag">{product.tag}</span><span className={`market-ribbon ${product.marketplace}`}>{marketplaceLabels[product.marketplace]}</span></div>
        <div className="detail-info">
          <div className="detail-brand">{product.brand}<button><Icon name="heart" /></button></div>
          <h1>{product.name}</h1>
          <p className="rating">★★★★★ <b>4.8</b> <span>리뷰 248개</span></p>
          <div className="detail-price"><del>{formatPrice(product.original)}</del><div><b>{Math.round((1 - product.price / product.original) * 100)}%</b><strong>{formatPrice(product.price)}</strong></div></div>
          <div className="detail-benefit"><span>혜택</span><p><b>최대 10,000원</b> 추가 할인 가능<br /><small>신규 회원 쿠폰 + 카드 할인</small></p></div>
          <div className="detail-benefit"><span>배송</span><p><b>무료배송</b><br /><small>내일 도착 예정</small></p></div>
          <label className="option">옵션 선택<select><option>옵션을 선택해주세요</option><option>블랙 / 기본</option><option>실버 / 기본</option></select></label>
          <button className="catch-button" onClick={onCatch}><Icon name="bell" /> 목표가가 되면 알려주세요 <span>조건 설정</span></button>
          <div className="detail-actions"><button className="outline" onClick={onAdd}><Icon name="cart" /> CATCH</button><button className="primary" onClick={onMove}>이동하기</button></div>
        </div>
      </div>
      <div className="detail-tabs"><button className="active">상품정보</button><button>리뷰 248</button><button>Q&A 32</button><button>배송/교환/반품</button></div>
    </main>
  );
}

function StorePreview({ product, onBack, onAdd }: { product: Product; onBack: () => void; onAdd: () => void }) {
  const discount = Math.round((1 - product.price / product.original) * 100);
  return (
    <main className={`store-preview ${product.marketplace}`}>
      <div className="store-preview-notice">CATCHCATCH 와이어프레임 · 실제 쇼핑몰 결제 페이지가 아닙니다</div>
      <header className="store-preview-header">
        <button onClick={onBack}><Icon name="chevron" size={17} /> CATCHCATCH로 돌아가기</button>
        <strong>{marketplaceLabels[product.marketplace].replace(" 상품", "")}</strong>
        <div><span>상품 검색</span><Icon name="search" size={18} /></div>
      </header>
      <div className="store-preview-body">
        <div className="store-breadcrumb">홈 / {product.category} / {product.brand}</div>
        <section className="store-product">
          <div className="store-product-image"><img src={product.image} alt={product.name} /><span>{marketplaceLabels[product.marketplace]}</span></div>
          <div className="store-product-info">
            <span className="store-brand">{product.brand}</span>
            <h1>{product.name}</h1>
            <p className="store-rating">★★★★★ <b>4.8</b> <span>리뷰 248개</span></p>
            <div className="store-price"><del>{formatPrice(product.original)}</del><div><b>{discount}%</b><strong>{formatPrice(product.price)}</strong></div></div>
            <div className="store-delivery"><Icon name="check" size={17} /><p><b>무료배송</b><small>지금 주문하면 내일 도착 예정</small></p></div>
            <label className="option">옵션 선택<select><option>기본 옵션</option><option>블랙</option><option>화이트</option></select></label>
            <button className="store-buy" onClick={onAdd}>CATCH에 담기</button>
            <small className="store-guide">실제 구매와 결제 기능은 추후 연결될 예정입니다.</small>
          </div>
        </section>
      </div>
    </main>
  );
}

const starterMarketPosts = [
  { id: 1, author: "소확행러", avatar: "소", image: products[1].image, caption: "할인 알림 받고 고민하던 에어포스 드디어 샀어요. 어디에나 잘 어울려서 만족!", product: products[1], likes: 128, comments: ["진짜 예쁘네요!", "착화감도 궁금해요"] },
  { id: 2, author: "퇴근후홈카페", avatar: "홈", image: products[2].image, caption: "주말 아침 첫 모카포트 개시. CATCH에서 찾은 가격이라 더 뿌듯합니다.", product: products[2], likes: 84, comments: ["분위기 너무 좋아요", "커피 향이 여기까지 나는 것 같아요"] },
  { id: 3, author: "디지털수집가", avatar: "디", image: products[6].image, caption: "운동 기록용으로 산 워치6. 화면도 선명하고 스트랩 컬러도 마음에 들어요.", product: products[6], likes: 203, comments: ["손목에 딱 잘 어울려요!", "저도 이 가격 기다리는 중이에요"] },
];

function MarketView() {
  const [posts, setPosts] = useState(starterMarketPosts);
  const [liked, setLiked] = useState<number[]>([]);
  const [openComments, setOpenComments] = useState<number | null>(null);
  const [comment, setComment] = useState("");
  const [composerOpen, setComposerOpen] = useState(false);
  const addComment = (postId: number) => {
    const body = comment.trim();
    if (!body) return;
    setPosts(posts.map((post) => post.id === postId ? { ...post, comments: [...post.comments, body] } : post));
    setComment("");
  };
  return (
    <main className="market-page">
      <div className="container market-head"><div><span className="eyebrow">CATCH COMMUNITY</span><h1>장터</h1><p>잘 산 제품을 인증하고, 다른 캐처들의 발견을 구경해보세요.</p></div><button className="primary" onClick={() => setComposerOpen(!composerOpen)}><Icon name="plus" /> 인증샷 올리기</button></div>
      {composerOpen && <div className="container market-composer"><div className="composer-drop"><Icon name="plus" size={26} /><b>인증샷을 선택해주세요</b><span>사진과 상품 정보를 함께 올릴 수 있어요</span></div><div><input placeholder="제품명을 입력하세요" /><input placeholder="구매 링크를 붙여넣으세요" /><textarea placeholder="어떤 점이 좋았나요?" /><button className="primary" onClick={() => setComposerOpen(false)}>피드에 올리기</button></div></div>}
      <section className="container market-feed">{posts.map((post) => { const isLiked = liked.includes(post.id); return <article className="market-post" key={post.id}>
        <header><span className="market-avatar">{post.avatar}</span><div><b>{post.author}</b><small>방금 전 · 구매 인증</small></div><button>•••</button></header>
        <div className="market-photo"><img src={post.image} alt={`${post.product.name} 구매 인증`} /><span>구매 인증</span></div>
        <div className="market-actions"><button className={isLiked ? "active" : ""} onClick={() => setLiked(isLiked ? liked.filter((id) => id !== post.id) : [...liked, post.id])}><Icon name="heart" /> {post.likes + (isLiked ? 1 : 0)}</button><button onClick={() => setOpenComments(openComments === post.id ? null : post.id)}><Icon name="comment" /> {post.comments.length}</button></div>
        <p className="market-caption"><b>{post.author}</b> {post.caption}</p>
        <button className="market-product"><img src={post.product.image} alt="" /><span><small>{marketplaceLabels[post.product.marketplace]}</small><b>{post.product.name}</b><strong>{formatPrice(post.product.price)}</strong></span><Icon name="chevron" /></button>
        {openComments === post.id && <div className="market-comments">{post.comments.map((item, index) => <p key={index}><b>{["가격요정", "데일리픽", "캐치러"][index % 3]}</b>{item}</p>)}<form onSubmit={(e) => { e.preventDefault(); addComment(post.id); }}><input value={comment} onChange={(e) => setComment(e.target.value)} placeholder="따뜻한 댓글을 남겨보세요" /><button>게시</button></form></div>}
      </article>; })}</section>
    </main>
  );
}

function SimpleView({ type, cart, onNavigate, onMove }: { type: string; cart: Product[]; onNavigate: (v: string) => void; onMove: (product: Product) => void }) {
  if (type === "cart") return (
    <main className="container simple-page">
      <div className="simple-title"><span>CATCH LIST</span><h1>CATCH</h1></div>
      {cart.length === 0 ? <div className="empty"><Icon name="cart" size={40} /><h2>CATCH가 비어있어요</h2><p>마음에 드는 핫딜을 담아보세요.</p><button className="primary" onClick={() => onNavigate("products")}>상품 보러가기</button></div> :
        <div className="cart-layout"><div className="cart-list">{cart.map((p) => <div className="cart-item" key={p.id}><input type="checkbox" defaultChecked /><img src={p.image} alt="" /><div><span>{p.brand}</span><strong>{p.name}</strong><small>옵션: 기본</small></div><div className="cart-item-action"><b>{formatPrice(p.price)}</b><button className="primary" onClick={() => onMove(p)}>이동하기</button></div></div>)}</div></div>}
    </main>
  );
  return (
    <main className="container simple-page">
      <div className="simple-title"><span>MY ACTIVITY</span><h1>내 활동</h1></div>
      <div className="my-stats"><div><b>3</b><span>CATCH 알림</span></div><div><b>7</b><span>찜한 상품</span></div><div><b>2</b><span>장터 게시물</span></div><div><b>12</b><span>받은 하트</span></div></div>
      <div className="my-menu"><button><Icon name="bell" /><span><b>내 CATCH 알림</b><small>목표가와 재고 알림을 관리해요</small></span><Icon name="chevron" /></button><button><Icon name="heart" /><span><b>찜한 상품</b><small>저장해 둔 상품을 모아봐요</small></span><Icon name="chevron" /></button><button onClick={() => onNavigate("market")}><Icon name="comment" /><span><b>내 장터 활동</b><small>인증샷과 댓글을 확인해요</small></span><Icon name="chevron" /></button></div>
    </main>
  );
}

function Modal({ type, product, onClose, onAuthenticated, moveRequested = false }: { type: string; product?: Product; onClose: () => void; onAuthenticated: () => void; moveRequested?: boolean }) {
  const [done, setDone] = useState(false);
  const [authMode, setAuthMode] = useState<"login" | "signup">("login");
  const [price, setPrice] = useState(product ? Math.floor(product.price * 0.9 / 1000) * 1000 : 0);
  return (
    <div className="modal-backdrop" onMouseDown={onClose}>
      <section className="modal" onMouseDown={(e) => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose}><Icon name="close" /></button>
        {type === "login" && authMode === "login" ? (
          <>
            <span className="modal-logo">CATCH<span>CATCH</span></span>
            <h2>{moveRequested ? <>로그인 후 쇼핑몰로<br />이동할 수 있어요</> : <>로그인하고 더 정확하게<br />핫딜을 잡아보세요</>}</h2>
            <p>{moveRequested ? "회원에게 제공되는 안전한 쇼핑몰 연결 서비스예요." : "관심 상품의 가격 변화를 놓치지 않도록 알려드려요."}</p>
            <div className="social-buttons"><button className="kakao" onClick={onAuthenticated}>K 카카오로 계속하기</button><button className="naver" onClick={onAuthenticated}>N 네이버로 계속하기</button><button className="google" onClick={onAuthenticated}>G Google로 계속하기</button></div>
            <div className="divider"><span>또는 이메일로 로그인</span></div>
            <form className="login-form" onSubmit={(e) => { e.preventDefault(); onAuthenticated(); }}><input type="email" placeholder="이메일" required /><input type="password" placeholder="비밀번호" required /><button className="primary">로그인</button></form>
            <div className="modal-links"><button>아이디 찾기</button><i /><button>비밀번호 찾기</button><i /><button onClick={() => setAuthMode("signup")}>회원가입</button></div>
          </>
        ) : type === "login" ? (
          <>
            <span className="modal-logo">CATCH<span>CATCH</span></span>
            <h2>회원가입하고<br />핫딜을 바로 만나보세요</h2>
            <p>간단한 정보만 입력하면 쇼핑몰 이동과 CATCH 알림을 이용할 수 있어요.</p>
            <form className="login-form signup-form" onSubmit={(e) => { e.preventDefault(); onAuthenticated(); }}><input type="text" placeholder="이름" required /><input type="email" placeholder="이메일" required /><input type="password" placeholder="비밀번호" required /><input type="password" placeholder="비밀번호 확인" required /><button className="primary">회원가입</button></form>
            <div className="modal-links"><span>이미 계정이 있나요?</span><button onClick={() => setAuthMode("login")}>로그인</button></div>
          </>
        ) : done ? (
          <div className="success-state"><span><Icon name="check" size={34} /></span><h2>CATCH 설정 완료!</h2><p><b>{product?.name}</b><br />조건이 맞는 순간 바로 알려드릴게요.</p><button className="primary" onClick={onClose}>확인</button></div>
        ) : (
          <>
            <span className="modal-kicker">CATCH LIVE DEAL</span>
            <h2>어떤 순간에<br />알려드릴까요?</h2>
            <p>가격과 재고 조건을 설정하면 실시간으로 확인해드려요.</p>
            <div className="catch-product"><img src={product?.image} alt="" /><div><span>{product?.brand}</span><strong>{product?.name}</strong><b>현재 {product && formatPrice(product.price)}</b></div></div>
            <label className="price-input"><span>목표 가격</span><div><input value={price.toLocaleString()} onChange={(e) => setPrice(Number(e.target.value.replace(/[^0-9]/g, "")))} /><b>원 이하</b></div><small>현재가보다 {product ? Math.max(0, Math.round((1 - price / product.price) * 100)) : 0}% 낮은 가격이에요</small></label>
            <label className="toggle-row"><span><b>재고 알림도 받을게요</b><small>품절 상품이 다시 입고되면 알려드려요</small></span><input type="checkbox" defaultChecked /></label>
            <button className="primary modal-submit" onClick={() => setDone(true)}>이 조건으로 CATCH 하기</button>
          </>
        )}
      </section>
    </div>
  );
}

function Footer() {
  return (
    <footer><div className="container footer-grid"><div className="footer-brand"><span>CATCH<span>CATCH</span></span><p>세상의 모든 핫딜을 가장 빠르게.<br />가격을 비교하고, 기회를 잡으세요.</p></div><div><strong>서비스</strong><button>실시간 핫딜</button><button>CATCH 알림</button><button>베스트</button></div><div><strong>고객지원</strong><button>공지사항</button><button>자주 묻는 질문</button><button>문의하기</button></div><div className="support"><strong>고객센터</strong><b>1588-2847</b><span>평일 09:00–18:00</span></div></div><div className="container footer-bottom"><span>© 2025 CATCHCATCH. All rights reserved.</span><div><button>이용약관</button><button>개인정보처리방침</button></div></div></footer>
  );
}

export default function App() {
  const [view, setView] = useState("home");
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<Product>(products[0]);
  const [modal, setModal] = useState<"login" | "catch" | null>(null);
  const [cart, setCart] = useState<Product[]>([]);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [pendingMove, setPendingMove] = useState<Product | null>(null);
  const [showLoginNotice, setShowLoginNotice] = useState(false);
  const [appBar, setAppBar] = useState(true);
  const navigate = (v: string) => { setView(v); window.scrollTo({ top: 0, behavior: "smooth" }); };
  const search = (term: string) => { setQuery(term); navigate("products"); };
  const select = (p: Product) => { setSelected(p); navigate("detail"); };
  const addCart = () => { if (!cart.find((p) => p.id === selected.id)) setCart([...cart, selected]); navigate("cart"); };
  const moveToStore = (product: Product) => {
    setSelected(product);
    navigate("store");
  };
  const requestMove = (product: Product) => {
    if (isLoggedIn) {
      moveToStore(product);
      return;
    }
    setSelected(product);
    setPendingMove(product);
    setModal("login");
  };
  const completeAuthentication = () => {
    setIsLoggedIn(true);
    setShowLoginNotice(true);
    setModal(null);
    if (pendingMove) moveToStore(pendingMove);
    setPendingMove(null);
  };
  const logout = () => {
    setIsLoggedIn(false);
    setShowLoginNotice(false);
    navigate("home");
  };
  return (
    <div className="app">
      {appBar && <div className="app-bar"><div className="container"><span className="app-mark">C</span><div><b>앱에서 더 빠르게 핫딜을 잡아보세요</b><small>가격 알림을 실시간으로 받아볼 수 있어요</small></div><button className="download">앱 다운로드</button><button className="bar-close" onClick={() => setAppBar(false)}><Icon name="close" size={18} /></button></div></div>}
      <Header onLogin={() => { setPendingMove(null); setModal("login"); }} onLogout={logout} onSearch={search} onNavigate={navigate} cartCount={cart.length} isLoggedIn={isLoggedIn} />
      {showLoginNotice && <div className="login-notice"><span><Icon name="check" size={17} /></span><div><b>로그인되었습니다</b><small>이제 모든 핫딜의 쇼핑몰 이동과 CATCH 알림을 이용할 수 있어요.</small></div><button onClick={() => setShowLoginNotice(false)} aria-label="로그인 알림 닫기"><Icon name="close" size={16} /></button></div>}
      {view === "home" && <Home onNavigate={navigate} onSelect={select} onCatch={(p) => { setSelected(p); setModal("catch"); }} />}
      {(view === "products" || view === "catch-deals") && <ProductsView query={query} catchDeals={view === "catch-deals"} onSelect={select} onCatch={(p) => { setSelected(p); setModal("catch"); }} />}
      {view === "wishlist" && <WishlistView onSelect={select} onCatch={(p) => { setSelected(p); setModal("catch"); }} />}
      {view === "detail" && <DetailView product={selected} onCatch={() => setModal("catch")} onAdd={addCart} onMove={() => requestMove(selected)} />}
      {view === "store" && <StorePreview product={selected} onBack={() => navigate("detail")} onAdd={addCart} />}
      {view === "market" && <MarketView />}
      {(view === "cart" || view === "mypage") && <SimpleView type={view} cart={cart} onNavigate={navigate} onMove={requestMove} />}
      <Footer />
      {modal && <Modal type={modal} product={selected} onClose={() => { setModal(null); setPendingMove(null); }} onAuthenticated={completeAuthentication} moveRequested={Boolean(pendingMove)} />}
      <nav className="mobile-nav"><button onClick={() => navigate("home")}><Icon name="home" /><span>홈</span></button><button onClick={() => navigate("products")}><Icon name="search" /><span>검색</span></button><button onClick={() => navigate("market")}><Icon name="comment" /><span>장터</span></button><button onClick={() => navigate("mypage")}><Icon name="user" /><span>활동</span></button></nav>
    </div>
  );
}
