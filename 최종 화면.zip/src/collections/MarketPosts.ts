import type { CollectionConfig } from 'payload'

export const MarketPosts: CollectionConfig = {
  slug: 'market-posts',
  admin: {
    useAsTitle: 'productName',
    group: '장터',
    defaultColumns: ['authorName', 'productName', 'createdAt'],
  },
  access: {
    read: () => true,
    create: () => true,
    update: () => false,
    delete: () => false,
  },
  fields: [
    { name: 'authorName', type: 'text', required: true, maxLength: 30 },
    { name: 'caption', type: 'textarea', required: true, maxLength: 500 },
    { name: 'image', type: 'upload', relationTo: 'media', required: true },
    { name: 'productName', type: 'text', required: true, maxLength: 120 },
    { name: 'productPrice', type: 'number', required: true, min: 0 },
    {
      name: 'productPlatform',
      type: 'select',
      required: true,
      options: ['쿠팡', 'Temu', 'AliExpress', '기타'],
    },
    { name: 'productUrl', type: 'text' },
    {
      name: 'likes',
      type: 'number',
      defaultValue: 0,
      min: 0,
      access: { create: () => false, update: () => false },
    },
  ],
}
