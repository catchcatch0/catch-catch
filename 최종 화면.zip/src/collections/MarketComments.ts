import type { CollectionConfig } from 'payload'

export const MarketComments: CollectionConfig = {
  slug: 'market-comments',
  admin: {
    useAsTitle: 'authorName',
    group: '장터',
    defaultColumns: ['authorName', 'post', 'createdAt'],
  },
  access: {
    read: () => true,
    create: () => true,
    update: () => false,
    delete: () => false,
  },
  fields: [
    { name: 'post', type: 'relationship', relationTo: 'market-posts', required: true },
    { name: 'authorName', type: 'text', required: true, maxLength: 30 },
    { name: 'body', type: 'text', required: true, maxLength: 240 },
  ],
}
